import App from './App';
import { Dashboard, LoginPage, NotFoundPage } from './pages';

export const getRoutes = () => [
  {
    path: '/',
    element: <App />,
    children: [
      {
        path: '/',
        element: <LoginPage />,
      },
      {
        path: '/dashboard',
        element: <Dashboard />,
      },
      {
        path: '*',
        element: <NotFoundPage />,
      },
    ],
  },
];
