import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

type TZustandStore = {
  isLoggedIn: boolean;
  setIsLoggedIn: (isLoggedIn: boolean) => void;
};

const initialState = {
  isLoggedIn: false,
};

const useUserStore = create<TZustandStore>()(
  persist(
    (set) => ({
      ...initialState,
      setIsLoggedIn: (isLoggedIn: boolean) => {
        if (!isLoggedIn) {
          set({ ...initialState });
        } else {
          set({ isLoggedIn });
        }
      },
    }),
    {
      name: 'userToken',
      storage: createJSONStorage(() => localStorage),
    }
  )
);

export default useUserStore;
