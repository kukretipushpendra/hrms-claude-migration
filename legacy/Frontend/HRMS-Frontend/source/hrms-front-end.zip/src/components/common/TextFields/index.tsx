import { TextFieldProps } from '@mui/material';
import { StyledTextFields } from './input.style';

const TextFields = (props: TextFieldProps) => {
  return <StyledTextFields {...props} />;
};

export default TextFields;
