export type { ErrorsBoundary } from './interfaces';
