import { ButtonProps } from '@mui/material';
import { StyledButtons } from './Buttons.style';

const Buttons = (props: ButtonProps) => {
  return <StyledButtons {...props}>{props.name}</StyledButtons>;
};

export default Buttons;
